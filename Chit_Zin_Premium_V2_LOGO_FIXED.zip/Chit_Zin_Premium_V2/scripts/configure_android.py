from pathlib import Path
from PIL import Image
import re

root = Path("android/app/src/main")
src = Path("public/chit-zin-logo.png")
if not src.exists():
    raise SystemExit("Logo asset not found")
img = Image.open(src).convert("RGBA")
# Crop to a centered square for Android launcher icons.
w, h = img.size
side = min(w, h)
img = img.crop(((w-side)//2, (h-side)//2, (w+side)//2, (h+side)//2))
sizes = {"mipmap-mdpi":48, "mipmap-hdpi":72, "mipmap-xhdpi":96, "mipmap-xxhdpi":144, "mipmap-xxxhdpi":192}
for folder, size in sizes.items():
    dest = root / "res" / folder
    dest.mkdir(parents=True, exist_ok=True)
    icon = img.resize((size, size), Image.Resampling.LANCZOS)
    icon.save(dest / "ic_launcher.png")
    icon.save(dest / "ic_launcher_round.png")
strings = root / "res" / "values" / "strings.xml"
if strings.exists():
    s = strings.read_text(encoding="utf-8")
    s = re.sub(r'(<string name="app_name">).*?(</string>)', r'\1ချစ်ဇနီးလေး\2', s)
    strings.write_text(s, encoding="utf-8")
