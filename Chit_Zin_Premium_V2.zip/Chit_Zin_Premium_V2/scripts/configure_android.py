from pathlib import Path
from PIL import Image
import re
root = Path('android/app/src/main')
src = Path('public/launcher-icon.png')
if not src.is_file(): raise SystemExit('ERROR: public/launcher-icon.png missing')
img = Image.open(src).convert('RGBA')
if img.width != img.height: raise SystemExit(f'ERROR: launcher icon must be square, got {img.size}')
sizes = {'mipmap-mdpi':48,'mipmap-hdpi':72,'mipmap-xhdpi':96,'mipmap-xxhdpi':144,'mipmap-xxxhdpi':192}
for folder,size in sizes.items():
    dest=root/'res'/folder; dest.mkdir(parents=True,exist_ok=True)
    icon=img.resize((size,size),Image.Resampling.LANCZOS)
    icon.save(dest/'ic_launcher.png', optimize=True)
    icon.save(dest/'ic_launcher_round.png', optimize=True)
n=432
fg=Image.new('RGBA',(n,n),(0,0,0,0))
art=img.resize((int(n*.72),int(n*.72)),Image.Resampling.LANCZOS)
fg.alpha_composite(art,((n-art.width)//2,(n-art.height)//2))
d=root/'res'/'drawable-nodpi'; d.mkdir(parents=True,exist_ok=True)
fg.save(d/'ic_launcher_foreground.png', optimize=True)
v=root/'res'/'values'; v.mkdir(parents=True,exist_ok=True)
(v/'launcher_icon_background.xml').write_text('<resources><color name="launcher_icon_background">#FF75B8</color></resources>',encoding='utf-8')
a=root/'res'/'mipmap-anydpi-v26'; a.mkdir(parents=True,exist_ok=True)
adaptive='''<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/launcher_icon_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
'''
for name in ('ic_launcher.xml','ic_launcher_round.xml'):
    (a/name).write_text(adaptive,encoding='utf-8')
manifest=root/'AndroidManifest.xml'
if not manifest.exists(): raise SystemExit('ERROR: AndroidManifest.xml missing')
m=manifest.read_text(encoding='utf-8')
def app_tag(match):
    attrs=re.sub(r'\s+android:(?:icon|roundIcon)="[^"]*"','',match.group(1))
    return '<application'+attrs+' android:icon="@mipmap/ic_launcher" android:roundIcon="@mipmap/ic_launcher_round">'
m2=re.sub(r'<application\b([^>]*)>',app_tag,m,count=1)
if m2==m or '@mipmap/ic_launcher' not in m2: raise SystemExit('ERROR: failed to set manifest launcher icon')
manifest.write_text(m2,encoding='utf-8')
strings=v/'strings.xml'
if strings.exists():
    s=strings.read_text(encoding='utf-8')
    if re.search(r'<string name="app_name">.*?</string>',s,re.S):
        s=re.sub(r'(<string name="app_name">).*?(</string>)',r'\1ချစ်ဇနီးလေး\2',s,flags=re.S)
    strings.write_text(s,encoding='utf-8')
gradle=Path('android/app/build.gradle')
if not gradle.exists(): raise SystemExit('ERROR: android/app/build.gradle missing')
g=gradle.read_text(encoding='utf-8')
g2=re.sub(r'versionCode\s+\d+', 'versionCode 2', g, count=1)
g2=re.sub(r'versionName\s+"[^"]*"', 'versionName "1.1.0"', g2, count=1)
if 'versionName "1.1.0"' not in g2 or 'versionCode 2' not in g2: raise SystemExit('ERROR: failed to update Android versionCode/versionName')
gradle.write_text(g2,encoding='utf-8')
for p in (root/'res/mipmap-xxxhdpi/ic_launcher.png', a/'ic_launcher.xml', d/'ic_launcher_foreground.png'):
    if not p.is_file() or p.stat().st_size < 100: raise SystemExit(f'ERROR: missing/empty launcher resource: {p}')
print('VERIFIED: launcher resources + manifest + Android versionName=1.1.0 versionCode=2')
