# ချစ်ဇနီးလေး Premium V2

- Burmese-first home organizer starter app.
- Theme choices: Pink, Lavender, Peach, Mint.
- Custom short-haired Myanmar girl mascot logo is used for the Android launcher icon.\n- Glossy jelly-style cards and corrected banner text: ချစ်ဇနီးလေး ခြွေတာစုဆောင်းကြမယ်နော်
- Local income/expense, groceries, chores, meals, pantry, reports, JSON backup.
- Pick multiple audio files from the phone using Android's system file picker. The persistent audio element remains alive while navigating between app pages.

## Build APK with GitHub Actions
1. Upload all files/folders in this project to a GitHub repository (keep `.github/workflows/build-apk.yml`).
2. Open Actions and run **Chit Zin APK Builder**, or push to main.
3. Download the `Chit-Zin-Premium-APK` artifact after a successful run.

## Important limitations
- This version stores household records locally on one device. Family sharing/cloud sync is not connected yet.
- In-app navigation does not destroy the audio player. True lock-screen/background playback while the Android app is backgrounded may require a native foreground media service and must be tested on the target Android phone; this starter does not claim that native service is implemented.
- Google Fonts requires internet; system fallback fonts are used offline.


## Updated features
- Notes with add/edit/delete and local storage
- Separate family calendar and savings goals pages
- Details dashboard and Settings credit popup photo
- Android launcher icon uses `public/launcher-icon.png`; in-app logo remains `public/chit-zin-logo.png`
