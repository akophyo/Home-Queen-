# ချစ်ဇနီး — GitHub APK Builder

Cute Pink, Burmese-first household organizer. The app stores data locally on the device using localStorage.

## Build a free Android APK with GitHub Actions

1. Create a new **Public** repository on GitHub named `chit-zin` (public repositories can use standard GitHub-hosted Actions runners within GitHub's free usage allowance).
2. On the repository page, choose **Add file → Upload files**.
3. Upload the contents of this ZIP (the files and folders inside `Home_Queen_GitHub_APK`, not the outer ZIP itself).
4. Commit the upload to the `main` branch.
5. Open the repository's **Actions** tab and select **Build ချစ်ဇနီး APK**.
6. Press **Run workflow** if it has not started automatically.
7. When the run finishes successfully, open that run, scroll to **Artifacts**, and download `Home-Queen-APK`.
8. Extract the artifact ZIP and install `app-debug.apk` on your Android phone. If Android asks, allow installation from that browser/file manager.

## Included modules

- Household income and expense register
- Grocery shopping checklist
- Chores checklist
- Meal planner
- Pantry inventory
- Family calendar
- Medicine reminder list (reminder list only, not medical advice)
- Savings goals
- Household helper tips
- JSON backup and restore

## Important notes

- This first build is an offline-first starter. Records stay on this device/browser/app installation.
- Cloud sync, user accounts, push notifications, payment/subscription handling, and real AI integration are not included yet.
- `app-debug.apk` is for testing and direct installation. A Play Store release needs a signed release build and store setup.
- GitHub Actions is free within GitHub's current included usage limits; public repositories generally have free standard runner usage. Check GitHub billing/usage if you hit a limit.

## Build locally (optional)

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```
