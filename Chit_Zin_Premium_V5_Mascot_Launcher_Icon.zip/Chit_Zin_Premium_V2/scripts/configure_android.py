from pathlib import Path
from PIL import Image
import re
root = Path("android/app/src/main")
src = Path("public/launcher-icon.png")
if not src.exists(): raise SystemExit("ERROR: launcher icon missing")
img = Image.open(src).convert("RGBA")
side = min(img.size)
img = img.crop(((img.width-side)//2, (img.height-side)//2, (img.width+side)//2, (img.height+side)//2))
sizes = {"mipmap-mdpi":48,"mipmap-hdpi":72,"mipmap-xhdpi":96,"mipmap-xxhdpi":144,"mipmap-xxxhdpi":192}
for folder,size in sizes.items():
    dest=root/"res"/folder
    dest.mkdir(parents=True,exist_ok=True)
    icon=img.resize((size,size),Image.Resampling.LANCZOS)
    icon.save(dest/"ic_launcher.png")
    icon.save(dest/"ic_launcher_round.png")
# Adaptive foreground artwork inset into Android safe zone
n=432
fg=Image.new("RGBA",(n,n),(0,0,0,0))
art=img.resize((int(n*.72),int(n*.72)),Image.Resampling.LANCZOS)
fg.alpha_composite(art,((n-art.width)//2,(n-art.height)//2))
d=root/"res"/"drawable-nodpi"; d.mkdir(parents=True,exist_ok=True)
fg.save(d/"ic_launcher_foreground.png")
v=root/"res"/"values"; v.mkdir(parents=True,exist_ok=True)
(v/"launcher_icon_background.xml").write_text('<resources><color name="launcher_icon_background">#FF75B8</color></resources>',encoding="utf-8")
a=root/"res"/"mipmap-anydpi-v26"; a.mkdir(parents=True,exist_ok=True)
adaptive='''<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/launcher_icon_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
'''
(a/"ic_launcher.xml").write_text(adaptive,encoding="utf-8")
(a/"ic_launcher_round.xml").write_text(adaptive,encoding="utf-8")
manifest=root/"AndroidManifest.xml"
if manifest.exists():
    m=manifest.read_text(encoding="utf-8")
    def app_tag(match):
        attrs=re.sub(r'\\s+android:(?:icon|roundIcon)="[^"]*"','',match.group(1))
        return '<application'+attrs+' android:icon="@mipmap/ic_launcher" android:roundIcon="@mipmap/ic_launcher_round">'
    m=re.sub(r'<application\\b([^>]*)>',app_tag,m,count=1)
    manifest.write_text(m,encoding="utf-8")
strings=v/"strings.xml"
if strings.exists():
    s=strings.read_text(encoding="utf-8")
    s=re.sub(r'(<string name="app_name">).*?(</string>)',r'\\1ချစ်ဇနီးလေး\\2',s)
    strings.write_text(s,encoding="utf-8")
print("Launcher icon installed: legacy + adaptive + explicit manifest")
